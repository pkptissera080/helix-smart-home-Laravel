<!DOCTYPE html>
<html lang="en">

<!-- head -->
<?php echo $__env->make('includes.common.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- End head -->

<body class="g-sidenav-show  bg-gray-200">

    <!-- sidebar -->
    <?php echo $__env->make('includes.common.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- End sidebar -->

    <main class="main-content position-relative max-height-vh-100 h-100 border-radius-lg ">
        <!-- Navbar -->
        <?php echo $__env->make('includes.common.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- End Navbar -->

        <div class="container-fluid py-4">

            <?php echo $__env->yieldContent('main-body-content'); ?>

            <!-- footer -->
            <?php echo $__env->make('includes.common.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- End footer -->
        </div>

    </main>

    <!-- script-src -->
    <?php echo $__env->make('includes.common.script-src', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- End script-src -->
</body>

</html><?php /**PATH D:\Projects\Personal Projects\helix-smart-home-Laravel\resources\views/master.blade.php ENDPATH**/ ?>