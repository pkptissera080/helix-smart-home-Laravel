

<?php $__env->startSection('main-body-content'); ?>

<div class="row mt-4">
    <div class="col-12">
        <div class="card">
            <!-- Card header -->
            <div class="card-header">
                <h5 class="mb-0">Sample</h5>
                <p class="text-sm mb-0">
                    ...........
                </p>
            </div>
            <div class="card-body">

            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\Personal Projects\helix-smart-home-Laravel\resources\views/pages/sample/sample.blade.php ENDPATH**/ ?>