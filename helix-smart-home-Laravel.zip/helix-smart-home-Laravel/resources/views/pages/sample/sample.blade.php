@extends('master')

@section('main-body-content')

<div class="row mt-4">
    <div class="col-12">
        <div class="card">
            <!-- Card header -->
            <div class="card-header">
                <h5 class="mb-0">Sample</h5>
                <p class="text-sm mb-0">
                    ...........
                </p>
            </div>
            <div class="card-body">

            </div>
        </div>
    </div>
</div>

@endsection